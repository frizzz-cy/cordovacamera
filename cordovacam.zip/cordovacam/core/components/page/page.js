export default {
  name: 'page'
};