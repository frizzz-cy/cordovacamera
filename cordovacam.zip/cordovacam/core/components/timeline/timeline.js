export default {
  name: 'timeline'
};