export default {
  name: 'block'
};